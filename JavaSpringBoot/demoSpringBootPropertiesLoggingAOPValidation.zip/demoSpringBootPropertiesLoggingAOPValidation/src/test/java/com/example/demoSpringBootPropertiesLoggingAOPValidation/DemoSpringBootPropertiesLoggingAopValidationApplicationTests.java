package com.example.demoSpringBootPropertiesLoggingAOPValidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringBootPropertiesLoggingAopValidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
