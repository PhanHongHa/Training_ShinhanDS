package com.example.demoSpringBootPropertiesLoggingAOPValidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringBootPropertiesLoggingAopValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBootPropertiesLoggingAopValidationApplication.class, args);
	}

}
